Circuit PNGs downloader

Qué contiene
- manifest.json: lista de 24 circuitos con el nombre final que necesita RaceControl
- download_circuit_pngs.py: descarga los mapas desde Wikimedia Commons y genera PNGs
- sources.csv: tabla rápida con nombre final, archivo fuente y página de atribución

Qué hace
- descarga cada archivo desde:
  https://commons.wikimedia.org/wiki/Special:Redirect/file/<source_file>
- si la fuente es SVG, la convierte a PNG usando cairosvg
- si la fuente ya es PNG, la guarda directamente
- crea la carpeta output/
- crea también real_circuit_pngs.zip con los 24 PNG ya listos

Cómo usar
1) En un equipo con internet:
   python3 -m pip install requests cairosvg
2) Ejecuta:
   python3 download_circuit_pngs.py
3) Te dejará:
   - output/*.png
   - real_circuit_pngs.zip

Nota importante
No he podido meter aquí directamente los PNG binarios descargados porque este entorno no me permite traer imágenes web y empaquetarlas ya hechas.
Por eso te dejo el descargador listo con 24 fuentes abiertas de Wikimedia Commons.
Revisa siempre las páginas de origen para la atribución/licencia concreta de cada circuito antes de redistribuirlos.