from __future__ import annotations

import json
import shutil
import zipfile
from pathlib import Path
from urllib.parse import quote

import requests

try:
    import cairosvg
except ImportError as exc:
    raise SystemExit(
        "Falta cairosvg. Instala dependencias con: python3 -m pip install requests cairosvg"
    ) from exc


BASE_URL = "https://commons.wikimedia.org/wiki/Special:Redirect/file/"
ROOT = Path(__file__).resolve().parent
OUT_DIR = ROOT / "output"
ZIP_PATH = ROOT / "real_circuit_pngs.zip"
MANIFEST_PATH = ROOT / "manifest.json"
TIMEOUT = 60


def load_manifest() -> list[dict]:
    return json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))


def build_url(source_file: str) -> str:
    return BASE_URL + quote(source_file, safe="()_-.")


def download_bytes(url: str) -> bytes:
    headers = {
        "User-Agent": "RaceControl-Circuit-Downloader/1.0"
    }
    response = requests.get(url, headers=headers, timeout=TIMEOUT)
    response.raise_for_status()
    return response.content


def save_png(item: dict, content: bytes) -> Path:
    target = OUT_DIR / item["target"]
    suffix = item["source_file"].lower().rsplit(".", 1)[-1]

    if suffix == "svg":
        cairosvg.svg2png(bytestring=content, write_to=str(target), output_width=1600)
    elif suffix == "png":
        target.write_bytes(content)
    else:
        raise ValueError(f"Formato no soportado: {item['source_file']}")

    return target


def verify_png(path: Path) -> None:
    signature = path.read_bytes()[:8]
    if signature != b"\x89PNG\r\n\x1a\n":
        raise ValueError(f"No es un PNG válido: {path.name}")


def build_zip(paths: list[Path]) -> None:
    if ZIP_PATH.exists():
        ZIP_PATH.unlink()

    with zipfile.ZipFile(ZIP_PATH, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for path in paths:
            zf.write(path, arcname=path.name)


def main() -> None:
    items = load_manifest()
    if OUT_DIR.exists():
        shutil.rmtree(OUT_DIR)
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    done: list[Path] = []
    failed: list[tuple[str, str]] = []

    for item in items:
        url = build_url(item["source_file"])
        try:
            content = download_bytes(url)
            out = save_png(item, content)
            verify_png(out)
            done.append(out)
            print(f"OK   {item['target']} <- {item['source_file']}")
        except Exception as exc:
            failed.append((item["target"], str(exc)))
            print(f"FAIL {item['target']} <- {item['source_file']} :: {exc}")

    if done:
        build_zip(done)
        print(f"\nZIP generado: {ZIP_PATH}")

    print(f"\nCompletados: {len(done)}")
    print(f"Fallidos: {len(failed)}")

    if failed:
        print("\nFallos:")
        for target, err in failed:
            print(f"- {target}: {err}")
        raise SystemExit(1)


if __name__ == "__main__":
    main()
